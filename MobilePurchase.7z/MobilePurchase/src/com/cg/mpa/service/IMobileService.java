package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.Exception.MobileException;
import com.cg.mpa.bean.Mobile;
import com.cg.mpa.bean.PurchaseDetails;

public interface IMobileService {
	List<Mobile> getMobiles() throws MobileException;
	
	int insertPurchase(PurchaseDetails pdetails) throws MobileException;

}
