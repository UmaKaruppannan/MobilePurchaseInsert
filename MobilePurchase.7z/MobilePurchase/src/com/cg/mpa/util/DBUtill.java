package com.cg.mpa.util;

	import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.mpa.Exception.MobileException;

import oracle.jdbc.pool.OracleDataSource;

	public class DBUtill

	{

	public static Connection getConnection() throws MobileException

	{
		InitialContext ic;
		DataSource ds;
		Connection con =null;
		


		try {
			if(con==null)
			{
		
		 ic=new InitialContext();
		 ds = (DataSource)
				 ic.lookup("java:/jdbc/OracleDS");
		 con=ds.getConnection();
		 return con;

		}
	}
catch (Exception e)
		{
			e.printStackTrace();
		}
	return con;
}
   }
	