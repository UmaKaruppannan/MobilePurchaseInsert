package com.cg.mpa.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.mpa.Exception.MobileException;
import com.cg.mpa.bean.Mobile;
import com.cg.mpa.bean.PurchaseDetails;
import com.cg.mpa.service.IMobileService;
import com.cg.mpa.service.MobileServiceImpl;


@WebServlet(urlPatterns={"/Home","/Buy","/purchase"})
public class MobileController extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public MobileController() {
        super();
      
    }

	
	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
	
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path=request.getServletPath();
	    String url="";
	    HttpSession sess;
	    
	    IMobileService mser = new MobileServiceImpl();
	    System.out.println(path);
	    try{
	    	switch(path)
	    	{
	    		case "/Home":
	    			List<Mobile> mlist = mser.getMobiles();
	    			request.setAttribute("mlist",mlist);
	    			url="Home.jsp";
	    			break;
	    			
	    		case "/Buy":
	    		 int mid = Integer.parseInt(request.getParameter("mid"));
	    		 sess=request.getSession(true);
	    		 sess.setAttribute("mid", mid);
	    		 url="Insert.jsp";
	    		 break;
	    		 
	    		case "/purchase":
	    		PurchaseDetails pdetails = new PurchaseDetails();
	    		pdetails.setCname(request.getParameter("cname"));
	    		pdetails.setCname(request.getParameter("mailid"));
	    		pdetails.setCname(request.getParameter("phoneno"));
	    		pdetails.setCname(request.getParameter("purchaseDate"));
	    		
	    		
	    		String dateStr=request.getParameter("purchaseDate");
	    		DateTimeFormatter fomat=DateTimeFormatter.ofPattern("yyyy-MM-dd");
	    		pdetails.setPurchaseDate(LocalDate.parse(dateStr,fomat));
	    		sess=request.getSession(false);
	    		pdetails.setMobileid((Integer)(sess.getAttribute("mid")));
	    		
	    		int pid=mser.insertPurchase(pdetails);
	    		request.setAttribute("pdetails",pdetails);
	    		url="Success.jsp";
	    		break;
	        	}
	    }catch (MobileException e){
	    	request.setAttribute("error", e.getMessage());
	    	url="Error.jsp";
	    	
	    	
	    }catch (Exception e){
	    	request.setAttribute("error", e.getMessage());
	    	url="Error.jsp";
	    	
	    }
		
		RequestDispatcher disp=request.getRequestDispatcher(url);
		disp.forward(request,response);
			
		
	}

}
