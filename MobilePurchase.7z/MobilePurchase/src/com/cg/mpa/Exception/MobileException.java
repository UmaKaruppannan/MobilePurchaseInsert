package com.cg.mpa.Exception;

public class MobileException extends Exception{

	
	public MobileException() {
		super();
	}
	
	
public MobileException(String message){
	super(message);
}
}
