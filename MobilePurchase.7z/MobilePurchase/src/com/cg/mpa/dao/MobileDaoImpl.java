package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.Exception.MobileException;
import com.cg.mpa.bean.Mobile;
import com.cg.mpa.bean.PurchaseDetails;
import com.cg.mpa.util.DBUtill;

public class MobileDaoImpl implements IMobileDao {

	Connection conn;
	
	@Override
	public List<Mobile> getMobiles() throws MobileException {
		String sql="Select * from mobiles";
		List<Mobile> mlist = new ArrayList<>();
		conn=DBUtill.getConnection();
		try{
			
		
		Statement st =conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
		while(rs.next())
		{
			Mobile m=new Mobile();
			m.setMobileid(rs.getInt("mobileid"));
			m.setName(rs.getString("name"));
			m.setPrice(rs.getDouble("price"));
			m.setQuantity(rs.getInt("quantity"));
			mlist.add(m);
		}
		}
		catch (SQLException e)
		{
			throw new MobileException("Problem in fetching Mobileid" +e.getMessage());
		}
			
		return mlist;
	}

	private int fetchPurchaseId() throws MobileException{
		String sql="SELECT seq1_purchaseid.NEXTVAL FROM dual";
		int pid;
		conn = DBUtill.getConnection();
		try{
		Statement st = conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
		rs.next();
		pid=rs.getInt(1);
		}
		catch (SQLException e)
		{
			throw new MobileException("Problem in fetching the purchaseid"+e.getMessage());
		}
		
			return pid;
		}
	
	
	@Override
	public int insertPurchase(PurchaseDetails pdetails) throws MobileException {
	String sql="Insert into purchasedetails Values(?,?,?,?,?,?)";
	pdetails.setPurchaseid(fetchPurchaseId());
	conn=DBUtill.getConnection();
	try{
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1, pdetails.getMobileid());
		pst.setString(2, pdetails.getCname());
		pst.setString(3,pdetails.getMailid());
		pst.setString(4,pdetails.getPhoneno());
		pst.setDate(5, Date.valueOf(pdetails.getPurchaseDate()));
		pst.setInt(6, pdetails.getMobileid());
		pst.executeUpdate();
	}
	catch (SQLException e)
	{
		throw new MobileException("problem in inserting purchase details"+e.getMessage());
	}
	return pdetails.getPurchaseid();
	
	}
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
