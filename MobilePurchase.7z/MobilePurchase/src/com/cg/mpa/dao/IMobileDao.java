package com.cg.mpa.dao;

import java.util.List;

import com.cg.mpa.Exception.MobileException;
import com.cg.mpa.bean.Mobile;
import com.cg.mpa.bean.PurchaseDetails;

public interface IMobileDao {
	
	List<Mobile> getMobiles() throws MobileException;
	
	int insertPurchase(PurchaseDetails pdetails) throws MobileException;;

}
